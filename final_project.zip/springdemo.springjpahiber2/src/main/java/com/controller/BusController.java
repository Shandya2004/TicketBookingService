package com.controller;

import com.model.Bus;
import com.repository.BusRepository;
import com.service.BusService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/student")
public class BusController {

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private BusService busService;

    // Admin Panel
    @RequestMapping("/adminlist")
    public String showAdmPanel(Model model) {
        Iterable<Bus> buses = busRepository.findAll();
        model.addAttribute("buses", buses);
        return "admin-main";
    }

    // Show Login Pages
    @RequestMapping("/user")
    public String showuserPanel() {
        return "user-login";
    }

    @RequestMapping("/admin")
    public String showAdminPanel() {
        return "admin-login";
    }

    @RequestMapping("/adminLog")
    public String showAdmin(Model model) {
        Iterable<Bus> buses = busRepository.findAll();
        model.addAttribute("buses", buses);
        return "admin-main";
    }

    @RequestMapping("/userLog")
    public String showUserPanel() {
        return "user-main";
    }

    // New Bus Form
    @RequestMapping("/new")
    public String showNewBusForm() {
        return "create-bus";
    }

    // Save Bus
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveBus(@ModelAttribute("bus") Bus bus) {
        busRepository.save(bus);
        return "redirect:/student/list";
    }

    // List All Buses
    @RequestMapping("/list")
    public String listBuses(Model model) {
        Iterable<Bus> buses = busRepository.findAll();
        model.addAttribute("buses", buses);
        return "list-bus";
    }

    // Search Buses
    @GetMapping("/searchBuses")
    public String searchBuses(@RequestParam("fromLocation") String fromLocation,
                              @RequestParam("toLocation") String toLocation,
                              @RequestParam("travelDate") String travelDate,
                              Model model) {
        // Fetch available buses using busService
        List<Bus> buses = busService.findAvailableBuses(fromLocation, toLocation, travelDate);
        model.addAttribute("buses", buses);
        return "busResults"; // returns the result view where buses are listed
    }

    // Edit Bus Form
    @RequestMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Bus bus = busService.getBusById(id);
        model.addAttribute("bus", bus);
        return "edit-bus";
    }

    // Update Bus
    @PostMapping("/update/{id}")
    public String updateBus(@PathVariable("id") Long id, @ModelAttribute("bus") Bus bus) {
        bus.setId(id); // Make sure the ID is set for updating
        busService.saveBus(bus);
        return "redirect:/student/list";
    }

    // Delete Bus
    @RequestMapping("/delete/{id}")
    public String deleteBus(@PathVariable("id") Long id) {
        busService.deleteBus(id);
        return "redirect:/student/list";
    }

    // View Bus Details
    @RequestMapping("/view/{id}")
    public String viewBus(@PathVariable("id") Long id, Model model) {
        Bus bus = busService.getBusById(id);
        model.addAttribute("bus", bus);
        return "view-bus";
    }
}
