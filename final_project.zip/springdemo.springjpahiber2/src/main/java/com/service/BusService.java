package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Bus;
import com.repository.BusRepository;
@Service
public class BusService {
	
	
	@Autowired
    private BusRepository busRepository;

    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    public Bus saveBus(Bus bus) {
        return busRepository.save(bus);
    }

    public void deleteBus(Long id) {
        busRepository.deleteById(id);
    }

    public Bus getBusById(Long id) {
        return busRepository.findById(id).orElse(null);
    }
    public List<Bus> findAvailableBuses(String from, String to, String date) {
        return busRepository.findByPickupLocationAndDropLocationAndTripDate(from, to, date);
    }
}
